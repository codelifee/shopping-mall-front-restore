import furniture from './images/furniture.jpg';
import bedroom from './images/bedroom.jpg';
import kitchen from './images/kitchen.jpg';
import bathroom from './images/bathroom.jpg';

export default [
    {
        id:0,
        title:"Living room collection",
        img: furniture

    },
    {
        id:1,
        title:"Bedroom collection",
        img: bedroom

    },
    {
        id:2,
        title:"Kitchen collection",
        img: kitchen

    },
    {
        id:3,
        title:"Bathroom collection",
        img: bathroom

    }
]