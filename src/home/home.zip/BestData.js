import bed from './images/bed.jpg';
import bookshelf from './images/bookshelf.jpg';
import chair from './images/chair.jpg';
import rug from './images/rug.jpg';
import sofa from './images/sofa.jpg';
import table from './images/table.jpg';


export default [
    {
        id:0,
        img: bed

    },
    {
        id:1,
        img: bookshelf

    },
    {
        id:2,
        img: chair

    },
    {
        id:3,
        img: rug

    },
    {
        id:4,
        img: sofa

    },
    {
        id:5,
        img: table

    }
]