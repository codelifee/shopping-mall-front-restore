import new1 from './images/new1.jpg';
import new2 from './images/new2.jpg';
import new3 from './images/new3.jpg';




export default [
    {
        id:0,
        img: new1

    },
    {
        id:1,
        img: new2

    },
    {
        id:2,
        img: new3

    }
]